package itso.rad7.ant.hello;

public class HelloAnt {

	public static void main(String[] args) {
		System.out.println("Hello from Turkey!");
	}
}
