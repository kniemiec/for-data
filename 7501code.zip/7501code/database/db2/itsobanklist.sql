
CONNECT TO ITSOBANK

echo - Customer -
SELECT ssn, char(title,4), char(firstname,10) as FIRSTNAME, char(lastname,10) as LASTNAME FROM ITSO.CUSTOMER

echo - Customer Account -
SELECT * FROM ITSO.ACCOUNTS_CUSTOMERS

echo - Account-

SELECT * FROM ITSO.ACCOUNT

echo - Transactions -
SELECT char(id,14) as ID, char(transtype,8) as TYPE, transtime, accounts_id, amount FROM ITSO.TRANSACTIONS
