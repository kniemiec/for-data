
SELECT ssn, char(title,4), char(firstname,10) as FIRSTNAME, char(lastname,10) as LASTNAME FROM ITSO.CUSTOMER;

SELECT * FROM ITSO.ACCOUNTS_CUSTOMERS;

SELECT * FROM ITSO.ACCOUNT;

SELECT char(id,14) as ID, char(transtype,8) as TYPE, transtime, accounts_id, amount FROM ITSO.TRANSACTIONS;
