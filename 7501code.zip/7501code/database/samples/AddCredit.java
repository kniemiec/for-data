/**
 * JDBC Stored Procedure AddCredit
 * @param PARTIALNAME  
 */
package itso.rad7.data;

import java.sql.*;                   // JDBC classes

public class AddCredit
{
	public static void addCredit ( String PARTIALNAME,
	                               ResultSet[] rs1 ) throws SQLException, Exception
	{
		// Get connection to the database
		Connection con = DriverManager.getConnection("jdbc:default:connection");
		PreparedStatement stmt = null;
		boolean bFlag;
		String sql;

		sql = "SELECT CUSTOMER.FIRSTNAME, CUSTOMER.LASTNAME, ACCOUNT.ID, ACCOUNT.BALANCE"
		    + "   FROM"
		    + "        CUSTOMER JOIN ACCOUNTS_CUSTOMERS ON CUSTOMER.SSN = ACCOUNTS_CUSTOMERS.CUSTOMERS_SSN JOIN ACCOUNT ON ACCOUNTS_CUSTOMERS.ACCOUNTS_ID = ACCOUNT.ID"
		    + "   WHERE CUSTOMER.LASTNAME LIKE  ?";
		stmt = con.prepareStatement( sql );
		stmt.setString( 1, PARTIALNAME );
		bFlag = stmt.execute();
		rs1[0] = stmt.getResultSet();
		String sql2 = "UPDATE ITSO.ACCOUNT  SET BALANCE = (BALANCE + 100)"
			+ " WHERE ID IN " + 
		"(SELECT ITSO.ACCOUNT.ID FROM ITSO.ACCOUNT JOIN ITSO.ACCOUNTS_CUSTOMERS"
				+ " ON ITSO.ACCOUNT.ID = ITSO.ACCOUNTS_CUSTOMERS.ACCOUNTS_ID"
				+ " JOIN ITSO.CUSTOMER ON ITSO.ACCOUNTS_CUSTOMERS.CUSTOMERS_SSN =" 
				+ " ITSO.CUSTOMER.SSN" 
			+ " WHERE CUSTOMER.LASTNAME LIKE  ?)";
		stmt = con.prepareStatement(sql2);
		stmt.setString( 1, PARTIALNAME );
		stmt.executeUpdate();
	}
}