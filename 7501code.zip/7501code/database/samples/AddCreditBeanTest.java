package itso.rad7.dbbean;

public class AddCreditBeanTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			AddCreditBean bean = new AddCreditBean();
			bean.execute("C%");
			AddCreditBeanRow[] rows = bean.getRows();
			for (int i = 0; i < rows.length; i++) {
				System.out.println(rows[i].getCUSTOMER_FIRSTNAME() + " " + rows[i].getCUSTOMER_LASTNAME());
				System.out.println(rows[i].getACCOUNT_ID() + " Balance: " + rows[i].getACCOUNT_BALANCE());
				System.out.println("--------------------------------");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

}
