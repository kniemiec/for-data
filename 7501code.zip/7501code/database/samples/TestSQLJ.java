package itso.rad7.sqlj;

public class TestSQLJ {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			CustomerAccountInfo info = new CustomerAccountInfo();
			info.execute(99999);
			while (info.next()) {
				System.out.println("Customer name: " + info.getCUSTOMER_TITLE()
						+ " " + info.getCUSTOMER_FIRSTNAME() + " "
						+ info.getCUSTOMER_LASTNAME());
				System.out.println("Account ID:   " + info.getACCOUNT_ID() + 
									" Balance:  " + info.getACCOUNT_BALANCE());
				System.out.println("---------------------------------------");
			}
			info.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
