package itso.rad7.bank.facade.ejb;

import itso.rad7.bank.exception.*;
import itso.rad7.bank.model.*;
import itso.rad7.bank.model.ejb.*;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.math.BigDecimal;
import java.sql.Timestamp;

import com.ibm.etools.service.locator.ServiceLocatorManager;
import itso.rad7.bank.model.ejb.CreditLocalHome;
import itso.rad7.bank.model.ejb.CreditLocal;
import itso.rad7.bank.model.ejb.DebitLocalHome;
import itso.rad7.bank.model.ejb.DebitLocal;

/**
 * Bean implementation class for Enterprise Bean: EJBBank
 */
public class EJBBankBean implements javax.ejb.SessionBean {

	// constant for conversion between int and BigDecimal
	private static BigDecimal hundred = new BigDecimal(100);

	static final long serialVersionUID = 3206093459760846163L;

	private javax.ejb.SessionContext mySessionCtx;

	private final static String STATIC_CustomerLocalHome_REF_NAME = "ejb/Customer";

	private final static Class STATIC_CustomerLocalHome_CLASS = CustomerLocalHome.class;

	private final static String STATIC_AccountLocalHome_REF_NAME = "ejb/Account";

	private final static Class STATIC_AccountLocalHome_CLASS = AccountLocalHome.class;

	private final static String STATIC_CreditLocalHome_REF_NAME = "ejb/Credit";

	private final static Class STATIC_CreditLocalHome_CLASS = CreditLocalHome.class;

	private final static String STATIC_DebitLocalHome_REF_NAME = "ejb/Debit";

	private final static Class STATIC_DebitLocalHome_CLASS = DebitLocalHome.class;

	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}

	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}

	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
	}

	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}

	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}

	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}

	public Customer getCustomer(String ssn) throws InvalidCustomerException {
		CustomerLocal aCustomerLocal = find_CustomerLocalHome_findByPrimaryKey(ssn);
		Customer customer = new Customer(ssn, aCustomerLocal.getTitle(),
				aCustomerLocal.getFirstName(), aCustomerLocal.getLastName());
		return customer;
	}

	protected CustomerLocal find_CustomerLocalHome_findByPrimaryKey(
			String primaryKey) throws InvalidCustomerException {
		CustomerLocalHome aCustomerLocalHome = (CustomerLocalHome) ServiceLocatorManager
				.getLocalHome(STATIC_CustomerLocalHome_REF_NAME,
						STATIC_CustomerLocalHome_CLASS);
		try {
			if (aCustomerLocalHome != null)
				return aCustomerLocalHome.findByPrimaryKey(primaryKey);
		} catch (javax.ejb.FinderException fe) {
			// Customer not found
			throw new InvalidCustomerException(primaryKey);
		}
		return null;
	}

	public Account getAccount(String accountNumber)
			throws InvalidAccountException {
		AccountLocal anAccountLocal = find_AccountLocalHome_findByPrimaryKey(accountNumber);
		Account account = new Account(accountNumber, new BigDecimal(
				anAccountLocal.getBalance()).divide(hundred));
		return account;
	}

	protected AccountLocal find_AccountLocalHome_findByPrimaryKey(
			String primaryKey) throws InvalidAccountException {
		AccountLocalHome anAccountLocalHome = (AccountLocalHome) ServiceLocatorManager
				.getLocalHome(STATIC_AccountLocalHome_REF_NAME,
						STATIC_AccountLocalHome_CLASS);
		try {
			if (anAccountLocalHome != null)
				return anAccountLocalHome.findByPrimaryKey(primaryKey);
		} catch (javax.ejb.FinderException fe) {
			// Account not found
			throw new InvalidAccountException(primaryKey);
		}
		return null;
	}

	public void updateCustomer(String ssn, String title, String firstName,
			String lastName) throws InvalidCustomerException {
		CustomerLocal aCustomerLocal = find_CustomerLocalHome_findByPrimaryKey(ssn);
		aCustomerLocal.setTitle(title);
		aCustomerLocal.setFirstName(firstName);
		aCustomerLocal.setLastName(lastName);
	}

	public Account[] getAccounts(String ssn) throws InvalidCustomerException {

		CustomerLocal aCustomerLocal = find_CustomerLocalHome_findByPrimaryKey(ssn);

		Collection colAccounts = aCustomerLocal.getAccounts();
		Iterator itAccounts = colAccounts.iterator();
		Account[] arrAccount = new Account[colAccounts.size()];
		int i = 0;
		while (itAccounts.hasNext()) {
			AccountLocal accountLocal = (AccountLocal) itAccounts.next();
			Account account = new Account(accountLocal.getPrimaryKey()
					.toString(), new BigDecimal(accountLocal.getBalance())
					.divide(hundred));
			arrAccount[i++] = account;
		}
		return arrAccount;
	}

	public Transaction[] getTransactions(String accountNumber)
			throws InvalidAccountException {

		AccountLocal anAccountLocal = find_AccountLocalHome_findByPrimaryKey(accountNumber);
		Set setTransactions = anAccountLocal.getLog();
		Iterator itTransactions = setTransactions.iterator();
		Transaction[] arrTransaction = new Transaction[setTransactions.size()];
		for (int i=0; itTransactions.hasNext(); i++) {
			TransactionLocal transactionLocal = (TransactionLocal) itTransactions.next();
			Transaction transaction = null;
			if (transactionLocal instanceof CreditLocal) {
				transaction = new Credit((new BigDecimal(transactionLocal.getAmount())).divide(hundred));
			} else {
				transaction = new Debit((new BigDecimal(transactionLocal.getAmount())).divide(hundred));
			}
			transaction.setTimeStamp(new Timestamp(transactionLocal.getTimestamp().getTime()));
			arrTransaction[i] = transaction;
			sort: for (int j=0; j<i; j++) {
				if ( transaction.getTimeStamp().before( arrTransaction[j].getTimeStamp() ) ) {
					for (int k=i-1; k>=j; k--) { arrTransaction[k+1] = arrTransaction[k]; }
					arrTransaction[j] = transaction;
					break sort;
				}
			}
		}
		return arrTransaction;
	}

	public Customer[] getCustomers(String partialName) throws ITSOBankException {
		CustomerLocalHome aCustomerLocalHome = (CustomerLocalHome) ServiceLocatorManager
				.getLocalHome(STATIC_CustomerLocalHome_REF_NAME,
						STATIC_CustomerLocalHome_CLASS);
		try {
			Collection aCollection = aCustomerLocalHome.findByName(partialName);
			Iterator itCustomer = aCollection.iterator();
			Customer[] arrCustomer = new Customer[aCollection.size()];
			int i = 0;
			while (itCustomer.hasNext()) {
				CustomerLocal aCustomerLocal = (CustomerLocal) itCustomer
						.next();
				Customer cust = new Customer(aCustomerLocal.getPrimaryKey()
						.toString(), aCustomerLocal.getTitle(), aCustomerLocal
						.getFirstName(), aCustomerLocal.getLastName());
				arrCustomer[i++] = cust;
			}
			return arrCustomer;
		} catch (Exception e) {
			throw new ITSOBankException("Customers not found: " + partialName);
		}
	}

	public void deposit(String accountNumber, BigDecimal amount)
			throws InvalidAccountException, ITSOBankException {
		CreditLocal aCreditLocal = createCreditLocal(amount.multiply(hundred).intValue());
		AccountLocal anAccountLocal = find_AccountLocalHome_findByPrimaryKey(accountNumber);
		anAccountLocal.processTransaction(aCreditLocal);
	}

	protected CreditLocal createCreditLocal(int amount) throws ITSOBankException {
		CreditLocalHome aCreditLocalHome = (CreditLocalHome) ServiceLocatorManager
				.getLocalHome(STATIC_CreditLocalHome_REF_NAME, STATIC_CreditLocalHome_CLASS);
		try {
			if (aCreditLocalHome != null)
				return aCreditLocalHome.create(amount);
		} catch (javax.ejb.CreateException ce) {
			throw new ITSOBankException("Unable to create credit transaction (amount=" + amount + ")");
		}
		return null;
	}

	public void withdraw(String accountNumber, BigDecimal amount)
			throws InvalidAccountException, InvalidAmountException, ITSOBankException {
		DebitLocal aDebitLocal = createDebitLocal(amount.multiply(hundred).intValue());
		AccountLocal anAccountLocal = find_AccountLocalHome_findByPrimaryKey(accountNumber);
		anAccountLocal.processTransaction(aDebitLocal);
	}

	protected DebitLocal createDebitLocal(int amount) throws ITSOBankException {
		DebitLocalHome aDebitLocalHome = (DebitLocalHome) ServiceLocatorManager
				.getLocalHome(STATIC_DebitLocalHome_REF_NAME, STATIC_DebitLocalHome_CLASS);
		try {
			if (aDebitLocalHome != null)
				return aDebitLocalHome.create(amount);
		} catch (javax.ejb.CreateException ce) {
			throw new ITSOBankException("Unable to create debit transaction (amount=" + amount + ")");
		}
		return null;
	}

	public void transfer(String debitAccountNumber, String creditAccountNumber, BigDecimal amount) 
			throws InvalidAccountException, InvalidAmountException, ITSOBankException {
		withdraw(debitAccountNumber, amount);
		deposit(creditAccountNumber, amount);
	}

}
