package itso.rad7.bank.impl;

import itso.rad7.bank.exception.AccountAlreadyExistException;
import itso.rad7.bank.exception.CustomerAlreadyExistException;
import itso.rad7.bank.exception.ITSOBankException;
import itso.rad7.bank.exception.InvalidAccountException;
import itso.rad7.bank.exception.InvalidCustomerException;
import itso.rad7.bank.exception.InvalidTransactionException;
import itso.rad7.bank.facade.ejb.EJBBank;
import itso.rad7.bank.facade.ejb.EJBBankHome;
import itso.rad7.bank.ifc.Bank;
import itso.rad7.bank.model.Account;
import itso.rad7.bank.model.Customer;
import itso.rad7.bank.model.Transaction;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.ibm.etools.service.locator.ServiceLocatorManager;

public class ITSOBank implements Bank {

	private EJBBank ejbBank = null;

	private static ITSOBank bank = new ITSOBank();

	private final static String STATIC_EJBBankHome_REF_NAME = "ejb/EJBBank";

	private final static Class STATIC_EJBBankHome_CLASS = EJBBankHome.class;

	public static ITSOBank getBank() {
		return ITSOBank.bank;
	}

	private EJBBank getEJBBank() throws ITSOBankException {
		if (ejbBank == null) {
			EJBBankHome anEJBBankHome = (EJBBankHome) ServiceLocatorManager
				.getRemoteHome(STATIC_EJBBankHome_REF_NAME,	STATIC_EJBBankHome_CLASS);
			try {
				if (anEJBBankHome != null)
					ejbBank = anEJBBankHome.create();
				} catch (Exception e) {
				throw new ITSOBankException("Unable to create Bank EJB: "
						+ STATIC_EJBBankHome_REF_NAME + " " + e.getMessage());
			}
		}
		return ejbBank;
	}
	
	public void addCustomer(Customer customer) throws CustomerAlreadyExistException {
		// TODO Auto-generated method stub
		
	}

	public void closeAccountOfCustomer(Customer customer, Account account) throws InvalidAccountException, InvalidCustomerException {
		// TODO Auto-generated method stub
		
	}

	public void deposit(String accountNumber, BigDecimal amount) throws InvalidAccountException, InvalidTransactionException {
		try {
			getEJBBank().deposit(accountNumber, amount);
		} catch (Exception e) {
			throw new InvalidTransactionException("Unable to deposit " + amount + " to " + accountNumber + " (" + e.getMessage() +")");
		}
	}

	public ArrayList<Account> getAccountsForCustomer(String customerSsn) throws InvalidCustomerException {
		try {
			return new ArrayList<Account>(Arrays.asList( getEJBBank().getAccounts(customerSsn) ));
		} catch (Exception e) {
			throw new InvalidCustomerException("Unable to retrieve accounts for: " + customerSsn + " (" + e.getMessage() +")");
		}
	}

	public Map<String, Customer> getCustomers() {
		Map<String, Customer> customers = new HashMap<String, Customer>();
		try {
			Customer[] custarray = getEJBBank().getCustomers("%");
			for (int i=0; i<custarray.length; i++) {
				customers.put(custarray[i].getSsn(), custarray[i]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customers;
	}

	public ArrayList<Transaction> getTransactionsForAccount(String accountNumber) throws InvalidAccountException {
		try {
			return new ArrayList<Transaction>(Arrays.asList(getEJBBank().getTransactions(accountNumber)));
		} catch (Exception e) {
			throw new InvalidAccountException("Unable to retrieve transactions for: " + accountNumber + " (" + e.getMessage() +")");
		}
	}

	public void openAccountForCustomer(Customer customer, Account account) throws InvalidCustomerException, AccountAlreadyExistException {
		// TODO Auto-generated method stub

	}

	public void removeCustomer(Customer customer) throws InvalidCustomerException {
		// TODO Auto-generated method stub
		
	}

	public Account searchAccountByAccountNumber(String accountNumber) throws InvalidAccountException {
		try {
			return getEJBBank().getAccount(accountNumber);
		} catch (Exception e) {
			throw new InvalidAccountException(accountNumber + " (" + e.getMessage() +")");
		}
	}

	public Customer searchCustomerBySsn(String ssn) throws InvalidCustomerException {
		try {
			return getEJBBank().getCustomer(ssn);
		} catch (Exception e) {
			throw new InvalidCustomerException(ssn + " (" + e.getMessage() +")");
		}
	}

	public void transfer(String debitAccountNumber, String creditAccountNumber, BigDecimal amount) throws InvalidAccountException, InvalidTransactionException {
		try {
			getEJBBank().transfer(debitAccountNumber, creditAccountNumber, amount);
		} catch (Exception e) {
			throw new InvalidTransactionException("Unable to transfer " + amount + " from " + debitAccountNumber + " to "
					+ creditAccountNumber + " (" + e.getMessage() +")");
		}
	}

	public void updateCustomer(String ssn, String title, String firstName, String lastName) throws InvalidCustomerException {
		try {
			getEJBBank().updateCustomer(ssn, title, firstName, lastName);
		} catch (Exception e) {
			throw new InvalidCustomerException(ssn + "Unable to update customer (" + e.getMessage() +")");
		}
	}

	public void withdraw(String accountNumber, BigDecimal amount) throws InvalidAccountException, InvalidTransactionException {
		try {
			getEJBBank().withdraw(accountNumber, amount);
		} catch (Exception e) {
			throw new InvalidAccountException("Unable to withdraw " + amount + " from " + accountNumber + " (" + e.getMessage() +")");
		}
	}



}
