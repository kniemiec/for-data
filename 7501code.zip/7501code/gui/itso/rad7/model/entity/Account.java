package itso.rad7.model.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class Account implements Serializable {

	private String id = null;
	private BigDecimal balance = null;
	
	public Account(String id, BigDecimal balance) {
		this.id = id;
		this.balance = balance.divide( new BigDecimal(100) );
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getId() {
		return id;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance.divide( new BigDecimal(100) );
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public String toString(){
		return "Account Number: "+getId()+", Balance: "+getBalance();
	}
}
