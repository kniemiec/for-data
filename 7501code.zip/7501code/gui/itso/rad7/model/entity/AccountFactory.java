package itso.rad7.model.entity;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class AccountFactory {

	public AccountFactory(){}

	public Account findById(String id) throws SQLException {
		System.out.println("Retrieve account by id: " + id);
		PreparedStatement stmt = DatabaseManager.getInstance().getConnection().prepareStatement(
			"select balance from itso.account where id = ?");
		stmt.setString(1, id);
		ResultSet rs = stmt.executeQuery();
		rs.next();
		Account account = new Account(id,rs.getBigDecimal("balance"));
		return account;
	}

	public Vector findByCustomer(Customer cust) throws SQLException {
		String customerSSN = cust.getSsn();
		System.out.println("Retrieve account list by customer: " + customerSSN);
		PreparedStatement stmt = DatabaseManager.getInstance().getConnection().prepareStatement( 
			"select accounts_id from itso.accounts_customers where customers_ssn = ?");
		stmt.setString(1, customerSSN);
		ResultSet rs = stmt.executeQuery();
				
		Vector result = new Vector();
		
		while (rs.next()) {
			Account account = findById(rs.getString("accounts_id")); 
			result.add(account);
		}
		return result;
	}
}