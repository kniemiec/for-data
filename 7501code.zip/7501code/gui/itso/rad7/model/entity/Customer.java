package itso.rad7.model.entity;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Vector;

public class Customer implements Serializable {

	private String ssn       = null;
	private String firstName = null;
	private String lastName  = null;
	private String title     = null;

	public Customer(String ssn, String firstName, String lastName) {
		setSsn(ssn);
		setFirstName(firstName);
		setLastName(lastName);
		setTitle("");
	}

	public String getFullName(){
		return getTitle() + " "	+ getFirstName() + " " + getLastName();
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getSsn() {
		return ssn;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public Vector getAccounts() throws SQLException {
		return new AccountFactory().findByCustomer(this);
	}

	public String toString() {
		return "Customer SSN: " + ssn + ", Name: " + title + " " + firstName + " " + lastName;
	}
	
	public Customer getSelf() {
		return this;
	}
}