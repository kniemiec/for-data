package itso.rad7.model.entity;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerFactory {

	public CustomerFactory() {}

	public Customer getCustomer(String ssn) throws SQLException {
		System.out.println("Retrieve customer by ssn: " + ssn);
		ResultSet rs = DatabaseManager.getInstance().getConnection().createStatement().executeQuery(
			"select * from itso.customer where ssn = '" + ssn + "'");
		rs.next();
		Customer customer = new Customer(rs.getString("ssn"), rs.getString("firstname"), rs.getString("lastname"));
		customer.setTitle(rs.getString("title"));
		return customer;
	}

}