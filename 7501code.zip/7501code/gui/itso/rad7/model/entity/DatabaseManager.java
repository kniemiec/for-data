package itso.rad7.model.entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseManager {
	private static DatabaseManager instance = null;
	static {
		if (instance == null)
			instance = new DatabaseManager();
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private DatabaseManager() {
	}

	public static DatabaseManager getInstance() {
		return instance;
	}

	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:derby:C:\\7501code\\database\\derby\\ITSOBANK");
		//return DriverManager.getConnection("jdbc:derby:E:\\SG247501-RAD7\\7501code\\database\\derby\\ITSOBANK");
	}

}
