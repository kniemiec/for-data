package itso.rad7.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import itso.rad7.client.ui.AccountTableModel;
import itso.rad7.client.ui.BankDesktop;
import itso.rad7.bank.exception.InvalidCustomerException;
import itso.rad7.bank.model.Account;
import itso.rad7.bank.model.Customer;
import com.ibm.etools.service.locator.ServiceLocatorManager;
import java.rmi.RemoteException;
import itso.rad7.bank.facade.ejb.EJBBankHome;
import itso.rad7.bank.facade.ejb.EJBBank;

public class BankDesktopController implements ActionListener {

	private BankDesktop desktop = null;

	private AccountTableModel accountTableModel = null;

	private final static String STATIC_EJBBankHome_REF_NAME = "ejb/EJBBank";

	private final static Class STATIC_EJBBankHome_CLASS = EJBBankHome.class;

	public BankDesktopController() {
		desktop = new BankDesktop();
		desktop.getBtnSearch().addActionListener(this);
		desktop.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		// we know that we are only listening to action events from
		// the search button, so...
		String ssn = desktop.getTfSSN().getText();
		EJBBank anEJBBank = createEJBBank();
		try {
			// look up the customer
			Customer customer = anEJBBank.getCustomer(ssn);
			// look up the accounts
			Account[] accounts = anEJBBank.getAccounts(ssn);
			
			// update the user interface
			desktop.getTfTitle().setText(customer.getTitle());
			desktop.getTfFirstName().setText(customer.getFirstName());
			desktop.getTfLastName().setText(customer.getLastName());
			setAccounts(accounts);
		}
		catch (InvalidCustomerException x) {
			// unknown customer. Report this using the output fields...
			desktop.getTfTitle().setText("(not found)");
			desktop.getTfFirstName().setText("(not found)");
			desktop.getTfLastName().setText("(not found)");
			setAccounts(new Account[0]);
		}
		catch (RemoteException x) {
			// unexpected RMI exception. Print it to the console and report it...
			x.printStackTrace();
			desktop.getTfTitle().setText("(internal error)");
			desktop.getTfFirstName().setText("(internal error)");
			desktop.getTfLastName().setText("(internal error)");
			setAccounts(new Account[0]);
		}
	}
	
	private void setAccounts(Account[] accounts) {
		if (accountTableModel == null) {
			accountTableModel = new AccountTableModel();
			desktop.getTblAccounts().setModel(accountTableModel);
		}
		accountTableModel.setAccounts(accounts);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BankDesktopController controller = new BankDesktopController();
	}

	protected EJBBank createEJBBank() {
		EJBBankHome anEJBBankHome = (EJBBankHome) ServiceLocatorManager
				.getRemoteHome(STATIC_EJBBankHome_REF_NAME,
						STATIC_EJBBankHome_CLASS);
		try {
			if (anEJBBankHome != null)
				return anEJBBankHome.create();
		} catch (javax.ejb.CreateException ce) {
			// TODO Auto-generated catch block
			ce.printStackTrace();
		} catch (RemoteException re) {
			// TODO Auto-generated catch block
			re.printStackTrace();
		}
		return null;
	}

}
