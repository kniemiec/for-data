package itso.rad7.example;

public class Car {

	private Engine carEngine = null;

	public Car(Engine carEgine) {
		this.setCarEngine(carEngine);
	}

	public Engine getCarEngine() {
		return this.carEngine;
	}

	private void setCarEngine(Engine carEngine) {
		if (carEngine != null) {
			this.carEngine = carEngine;
		} else {
			this.carEngine = new Engine();
		}
	}

	public void start() {
		this.carEngine.start();
	}
}
