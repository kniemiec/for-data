package itso.rad7.example;

public class Engine {

	public void start() {
		// code to start the engine
	}
}
