package itso.rad7.example;

public class HappyDriver {

	public static void main(String[] args) {
		Car myAdvancedCar = new Car(null);

		// Start the car - I don't care about technical details
		myAdvancedCar.start();
	}
}
