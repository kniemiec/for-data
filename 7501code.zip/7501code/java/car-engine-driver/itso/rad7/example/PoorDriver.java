package itso.rad7.example;

public class PoorDriver {

	public static void main(String[] args) {
		Car myCar = new Car(null);

		/*
		 * How can I start my car? Do I really have to touch the engine? - Yes,
		 * there is no other way at the moment.
		 */
		myCar.getCarEngine().start();
	}
}
