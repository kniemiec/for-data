/*
 * File Name:  BankClient.java 
 */
package itso.rad7.bank.client;

import itso.rad7.bank.exception.ITSOBankException;
import itso.rad7.bank.ifc.Bank;
import itso.rad7.bank.impl.ITSOBank;
import itso.rad7.bank.model.Account;
import itso.rad7.bank.model.Customer;

import java.math.BigDecimal;

public class BankClient {
	public static void main(String[] args) {
		try {
			Bank bank = ITSOBank.getBank();

			System.out.println("System is going to add new customer...");
			Customer customer1 = new Customer("xxx-xx-xxxx", "Mrs", "Julia",
					"Johnson");
			bank.addCustomer(customer1);
			System.out.println(customer1 + " has been successfully added.\n");

			System.out
					.println("System is going to open two new accounts for the customer "
							+ customer1 + "...");
			Account account11 = new Account("11", new BigDecimal(10000.00D));
			bank.openAccountForCustomer(customer1, account11);
			Account account12 = new Account("12", new BigDecimal(11234.23D));
			bank.openAccountForCustomer(customer1, account12);
			System.out
					.println("Account " + account11.getAccountNumber()
							+ " and account " + account12.getAccountNumber()
							+ " have been successfully opened for " + customer1
							+ ".\n");

			System.out.println("System is listing all account information of "
					+ customer1 + "...");
			System.out.println(bank.getAccountsForCustomer(customer1.getSsn()));

			BigDecimal amount = new BigDecimal(2500.00D);
			System.out.println("\nSystem is going to make credit of $"
					+ amount.setScale(2, BigDecimal.ROUND_HALF_EVEN)
					+ " to account " + account11.getAccountNumber() + "...");
			bank.deposit(account11.getAccountNumber(), amount);
			System.out.println("Account " + account11.getAccountNumber()
					+ " has sucessfully credited by $"
					+ amount.setScale(2, BigDecimal.ROUND_HALF_EVEN) + ".\n");

			amount = new BigDecimal(1234.23D);
			System.out.println("System is going to make debit of $"
					+ amount.setScale(2, BigDecimal.ROUND_HALF_EVEN)
					+ " to account " + account12.getAccountNumber() + "...");
			bank.withdraw(account12.getAccountNumber(), amount);
			System.out.println("Account " + account12.getAccountNumber()
					+ " has sucessfully debited by $"
					+ amount.setScale(2, BigDecimal.ROUND_HALF_EVEN) + ".\n");

			System.out.println("System is listing all account information of "
					+ customer1 + "...");
			System.out.println(bank.getAccountsForCustomer(customer1.getSsn()));

			System.out.println("\nSystem is going to close account "
					+ account11.getAccountNumber() + " of customer "
					+ customer1 + "...");
			bank.closeAccountOfCustomer(customer1, account11);
			System.out.println("Account " + account11.getAccountNumber()
					+ " has been successfully closed for " + customer1 + ".\n");

			System.out.println("System is listing all account information of "
					+ customer1 + "...");
			System.out.println(bank.getAccountsForCustomer(customer1.getSsn()));

			amount = new BigDecimal(5000.00D);
			System.out.println("\nSystem is going to make credit of $"
					+ amount.setScale(2, BigDecimal.ROUND_HALF_EVEN)
					+ " to account " + account12.getAccountNumber() + "...");
			bank.deposit(account12.getAccountNumber(), amount);
			System.out.println("Account " + account12.getAccountNumber()
					+ " has sucessfully credited by $"
					+ amount.setScale(2, BigDecimal.ROUND_HALF_EVEN) + ".\n");

			System.out.println("System is listing all account information of "
					+ customer1 + "...");
			System.out.println(bank.getAccountsForCustomer(customer1.getSsn()));

			System.out.println("\nSystem is listing all customers ...");
			System.out.println(bank.getCustomers() + "\n");
			java.util.Iterator iter = bank.getCustomers().values().iterator();
			while (iter.hasNext()) {
				Customer customer = (Customer) iter.next();
				System.out
						.println("Customer: "
								+ customer
								+ "\n"
								+ bank
										.getAccountsForCustomer(customer
												.getSsn()) + "\n");
			}
		} catch (ITSOBankException e) {
			e.printStackTrace();
		}
	}
}
