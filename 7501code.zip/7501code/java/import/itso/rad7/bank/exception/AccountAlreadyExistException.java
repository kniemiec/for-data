/*
 * File Name:  InvalidAccountException.java
 */
package itso.rad7.bank.exception;

public class AccountAlreadyExistException extends ITSOBankException {

	private static final long serialVersionUID = -580408960127210114L;
	private String accountNumber;

	public AccountAlreadyExistException(String accountNumber) {
		super("Invalid account: Account with number " + accountNumber
				+ " does already exist!");
		this.setAccountNumber(accountNumber);
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	private void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
}