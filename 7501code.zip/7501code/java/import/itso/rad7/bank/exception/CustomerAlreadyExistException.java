/*
 * File Name:  CustomerAlreadyExistException.java
 */
package itso.rad7.bank.exception;

public class CustomerAlreadyExistException extends ITSOBankException {

	private static final long serialVersionUID = -3313010076507588192L;
	private String ssn;

	public CustomerAlreadyExistException(String ssn) {
		super("Invalid customer: Customer with ssn " + ssn
				+ " does already exist!");
		this.setSsn(ssn);
	}

	public String getSsn() {
		return this.ssn;
	}

	private void setSsn(String ssn) {
		this.ssn = ssn;
	}
}
