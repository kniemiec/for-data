package itso.rad7.bank.exception;

public class ITSOBankException extends Exception {

	private static final long serialVersionUID = -5758729545681152548L;

	public ITSOBankException(String message) {
		super(message);
	}
}
