package itso.rad7.bank.exception;

public class InvalidAmountException extends ITSOBankException {

	private static final long serialVersionUID = 6699692701553657931L;
	private String amount = null;

	public InvalidAmountException(String amount) {
		super("Invalid amount: " + amount);
		this.setAmount(amount);
	}

	public String getAmount() {
		return this.amount;
	}

	private void setAmount(String amount) {
		this.amount = amount;
	}
}
