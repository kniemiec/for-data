/*
 * File Name:  InvalidCustomerException.java
 */
package itso.rad7.bank.exception;

public class InvalidCustomerException extends ITSOBankException {

	private static final long serialVersionUID = 115434485097773697L;
	private String ssn;

	public InvalidCustomerException(String ssn) {
		super("Invalid customer: Customer with ssn " + ssn + " does not exist!");
		this.setSsn(ssn);
	}

	public String getSsn() {
		return this.ssn;
	}

	private void setSsn(String ssn) {
		this.ssn = ssn;
	}
}
