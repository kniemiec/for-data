/*
 * File Name:  InvalidTransactionException.java
 */
package itso.rad7.bank.exception;

import itso.rad7.bank.model.Account;

import java.math.BigDecimal;

public class InvalidTransactionException extends ITSOBankException {

	private static final long serialVersionUID = -4756665135978155919L;
	private Account account;
	private String transactionType;
	private BigDecimal amount;

	public InvalidTransactionException(String message) {
		super(message);
		this.setTransactionType(null);
		this.setAmount(null);
		this.setAccount(null);
	}

	public InvalidTransactionException(Account account, String transactionType,
			BigDecimal amount) {
		super(transactionType.toLowerCase() + " transaction on account "
				+ account.getAccountNumber() + " failed: " + "Could not "
				+ transactionType.toLowerCase() + " $"
				+ amount.setScale(2, BigDecimal.ROUND_HALF_EVEN)
				+ ", because current balance is $"
				+ account.getBalance().setScale(2, BigDecimal.ROUND_HALF_EVEN)
				+ " and negative balances are not allowed.");
		this.setTransactionType(transactionType);
		this.setAmount(amount);
		this.setAccount(account);
	}

	public Account getAccount() {
		return this.account;
	}

	private void setAccount(Account account) {
		this.account = account;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	private void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	private void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
}