/*
 * File Name:  InvalidCustomerException.java
 */
package itso.rad7.bank.exception;

public class UnknownBankException extends Exception {
	private static final long serialVersionUID = 404475091021714536L;
	private String bankName;

	public UnknownBankException(String bankName) {
		super("Invalid bank: Banke with name " + bankName + " does not exist!");
		this.setBankName(bankName);
	}

	public String getBankName() {
		return this.bankName;
	}

	private void setBankName(String bankName) {
		this.bankName = bankName;
	}
}
