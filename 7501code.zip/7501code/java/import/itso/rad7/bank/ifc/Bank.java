/*
 * File Name:  Bank.java
 */
package itso.rad7.bank.ifc;

import itso.rad7.bank.exception.AccountAlreadyExistException;
import itso.rad7.bank.exception.CustomerAlreadyExistException;
import itso.rad7.bank.exception.InvalidAccountException;
import itso.rad7.bank.exception.InvalidCustomerException;
import itso.rad7.bank.exception.InvalidTransactionException;
import itso.rad7.bank.model.Account;
import itso.rad7.bank.model.Customer;
import itso.rad7.bank.model.Transaction;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

public interface Bank {

	public abstract void addCustomer(Customer customer)
			throws CustomerAlreadyExistException;

	public abstract void updateCustomer(String ssn, String title,
			String firstName, String lastName) throws InvalidCustomerException;

	public abstract void removeCustomer(Customer customer)
			throws InvalidCustomerException;

	public abstract void openAccountForCustomer(Customer customer,
			Account account) throws InvalidCustomerException,
			AccountAlreadyExistException;

	public abstract void closeAccountOfCustomer(Customer customer,
			Account account) throws InvalidAccountException,
			InvalidCustomerException;

	public abstract Customer searchCustomerBySsn(String ssn)
			throws InvalidCustomerException;

	public abstract Account searchAccountByAccountNumber(String accountNumber)
			throws InvalidAccountException;

	public abstract Map<String, Customer> getCustomers();

	public abstract ArrayList<Account> getAccountsForCustomer(String customerSsn)
			throws InvalidCustomerException;

	public abstract ArrayList<Transaction> getTransactionsForAccount(
			String accountNumber) throws InvalidAccountException;

	public abstract void deposit(String accountNumber, BigDecimal amount)
			throws InvalidAccountException, InvalidTransactionException;

	public abstract void withdraw(String accountNumber, BigDecimal amount)
			throws InvalidAccountException, InvalidTransactionException;

	public abstract void transfer(String debitAccountNumber,
			String creditAccountNumber, BigDecimal amount)
			throws InvalidAccountException, InvalidTransactionException;
}
