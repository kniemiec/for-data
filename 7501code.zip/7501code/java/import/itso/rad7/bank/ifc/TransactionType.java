/*
 * File Name:  TransactionType.java
 */
package itso.rad7.bank.ifc;

public interface TransactionType {

	public static final String DEBIT = "DEBIT";
	public static final String CREDIT = "CREDIT";
}
