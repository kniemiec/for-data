/*
 * File Name:  Account.java
 */
package itso.rad7.bank.model;

import itso.rad7.bank.exception.InvalidTransactionException;
import itso.rad7.bank.ifc.TransactionType;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;

public class Account implements Serializable {

	private static final long serialVersionUID = -1682730430512221805L;
	private String accountNumber;
	private BigDecimal balance;
	private ArrayList<Transaction> transactions;

	public Account(String accountNumber, BigDecimal balance) {
		this.setAccountNumber(accountNumber);
		this.setBalance(balance);
		this.setTransactions(new ArrayList<Transaction>());
	}

	public BigDecimal getBalance() {
		return this.balance;
	}

	private void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public String getAccountNumber() {
		return this.accountNumber;
	}

	private void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public ArrayList<Transaction> getTransactions() {
		return this.transactions;
	}

	private void setTransactions(ArrayList<Transaction> transactions) {
		this.transactions = transactions;
	}

	public void processTransaction(BigDecimal amount, String transactionType)
			throws InvalidTransactionException {

		BigDecimal newBalance = null;
		Transaction transaction = null;

		if (TransactionType.CREDIT.equals(transactionType)) {
			transaction = new Credit(amount);
		} else if (TransactionType.DEBIT.equals(transactionType)) {
			transaction = new Debit(amount);
		} else {
			throw new InvalidTransactionException(
					"Invalid transaction type: Please use Debit or Credit. "
							+ "No other transactions are currently supported.");
		}

		newBalance = transaction.process(this.getBalance());
		if (newBalance.doubleValue() < 0) {
			throw new InvalidTransactionException(this, transactionType, amount);
		} else {
			this.setBalance(newBalance);
			this.getTransactions().add(transaction);
		}
	}

	public String toString() {
		StringBuffer accountInfo = new StringBuffer();

		accountInfo.append("Account " + this.getAccountNumber()
				+ ": --> Current balance: $"
				+ this.getBalance().setScale(2, BigDecimal.ROUND_HALF_EVEN));
		if (this.getTransactions().size() > 0) {
			accountInfo.append(System.getProperty("line.separator"));
			accountInfo.append("\tTransactions: ");
			accountInfo.append(System.getProperty("line.separator"));
			for (int i = 0; i < this.getTransactions().size(); i++) {
				accountInfo.append("\t" + (i + 1) + ". "
						+ this.getTransactions().get(i) + "\n");
			}
		}
		return accountInfo.toString();
	}
}
