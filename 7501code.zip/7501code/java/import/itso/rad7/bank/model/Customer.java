/*
 * File Name:  Customer.java
 */
package itso.rad7.bank.model;

import itso.rad7.bank.exception.AccountAlreadyExistException;
import itso.rad7.bank.exception.InvalidAccountException;

import java.io.Serializable;
import java.util.ArrayList;

public class Customer implements Serializable {

	private static final long serialVersionUID = 1871790137891426588L;
	private String ssn;
	private String title;
	private String firstName;
	private String lastName;
	private ArrayList<Account> accounts;

	public Customer(String ssn, String title, String firstName, String lastName) {
		this.setSsn(ssn);
		this.setTitle(title);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setAccounts(new ArrayList<Account>());
	}

	public void addAccount(Account account) throws AccountAlreadyExistException {
		if (!this.getAccounts().contains(account)) {
			this.getAccounts().add(account);
		} else {
			throw new AccountAlreadyExistException(account.getAccountNumber());
		}
	}

	public void removeAccount(Account account) throws InvalidAccountException {
		if (this.getAccounts().contains(account)) {
			this.getAccounts().remove(account);
		} else {
			throw new InvalidAccountException(account.getAccountNumber());
		}
	}

	public void updateCustomer(String title, String firstName, String lastName) {
		this.setTitle(title);
		this.setFirstName(firstName);
		this.setLastName(lastName);
	}

	public String getSsn() {
		return this.ssn;
	}

	private void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getTitle() {
		return this.title;
	}

	private void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return this.firstName;
	}

	private void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	private void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public ArrayList<Account> getAccounts() {
		return this.accounts;
	}

	private void setAccounts(ArrayList<Account> accounts) {
		this.accounts = accounts;
	}

	public String toString() {
		return this.getSsn() + " " + this.getTitle() + " " + this.getLastName()
				+ " " + this.getFirstName();
	}
}
