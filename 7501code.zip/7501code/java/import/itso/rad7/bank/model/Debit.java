/*
 * File Name:  Debit.java
 */
package itso.rad7.bank.model;

import itso.rad7.bank.exception.InvalidTransactionException;
import itso.rad7.bank.ifc.TransactionType;

import java.math.BigDecimal;

public class Debit extends Transaction {

	private static final long serialVersionUID = -3018653208730299126L;

	public Debit(BigDecimal amount) {
		super(amount);
	}

	public BigDecimal process(BigDecimal accountBalance)
			throws InvalidTransactionException {
		if ((this.getAmount() != null)
				&& (this.getAmount().compareTo(new BigDecimal(0.00D)) > 0)) {
			return accountBalance.subtract(this.getAmount());
		} else {
			if (this.getAmount() != null) {
				throw new InvalidTransactionException(
						"Debit transaction could not proceed: "
								+ "Negative or zero debit amount has dedected. Debit amount is: $"
								+ this.getAmount().setScale(2,
										BigDecimal.ROUND_HALF_EVEN) + ".");
			} else {
				throw new InvalidTransactionException(
						"Debit transaction could not proceed: "
								+ "Debit amount is not set.");
			}
		}
	}

	public String getTransactionType() {
		return TransactionType.DEBIT;
	}

	public String toString() {
		if (this.getAmount() != null) {
			return "Debit: --> Amount $"
				+ this.getAmount().setScale(2, BigDecimal.ROUND_HALF_EVEN) + " on "
				+ this.getTimeStamp();
		} else {
			return "Debit amount is not set. Transaction has failed.";
		}
	}
}