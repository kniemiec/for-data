/*
 * File Name:  Transaction.java
 */

package itso.rad7.bank.model;

import itso.rad7.bank.exception.InvalidTransactionException;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public abstract class Transaction implements Serializable {

	private Timestamp timeStamp;
	private BigDecimal amount;
	private int transactionId = 0;

	public Transaction(BigDecimal amount) {
		this.setTimeStamp(new Timestamp(System.currentTimeMillis()));
		this.setAmount(amount);
		this.setTransactionId();
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	private void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Timestamp getTimeStamp() {
		return this.timeStamp;
	}

	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}

	private void setTransactionId() {
		this.transactionId += 1;
	}

	public int getTransactionId() {
		return this.transactionId;
	}

	public abstract BigDecimal process(BigDecimal accountBalance)
			throws InvalidTransactionException;

	public abstract String getTransactionType();
}
