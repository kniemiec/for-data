package itso.rad7.bank.test.junit;

import junit.framework.Test;
import junit.framework.TestSuite;

public class All381Tests_Example1 {

	public static Test suite() {

		// Automatically - runs all test...() methods
		TestSuite suite = new TestSuite(ITSOBank381Test.class,
				"All test cases of itso.rad7.bank.test.junit.ITSOBank381Test");
		return suite;
	}
}
