package itso.rad7.bank.test.junit;

import junit.framework.Test;
import junit.framework.TestSuite;

public class All381Tests_Example2 {

	public static Test suite() {
		TestSuite suite = new TestSuite();
		
		// Add manually single tests to the suite
		suite.addTest(new ITSOBank381Test("testSearchAccountByAccountNumber"));
		return suite;
	}
}
