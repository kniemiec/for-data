package itso.rad7.bank.test.junit;

import itso.rad7.bank.exception.InvalidAccountException;
import itso.rad7.bank.exception.InvalidCustomerException;
import itso.rad7.bank.ifc.Bank;
import itso.rad7.bank.impl.ITSOBank;
import itso.rad7.bank.model.Account;
import itso.rad7.bank.model.Customer;
import junit.framework.TestCase;

public class ITSOBank381Test extends TestCase {

	private Bank bank = null;
	private static final String ACCOUNT_NUMBER = "001-999000777";
	private static final String CUSTOMER_SSN = "111-11-1111";

	public ITSOBank381Test(String s) {
		super(s);
	}

	protected void setUp() throws Exception {
		super.setUp();

		// Instantiate objects
		this.bank = ITSOBank.getBank();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public final void testSearchAccountByAccountNumber() {

		// Invoke a method
		try {
			Account bankAccount = this.bank
					.searchAccountByAccountNumber(ITSOBank381Test.ACCOUNT_NUMBER);

			// Verify an assertion
			assertEquals(bankAccount.getAccountNumber(),
					ITSOBank381Test.ACCOUNT_NUMBER);
		} catch (InvalidAccountException e) {
			e.printStackTrace();
		}
	}

	public final void testSearchCustomerBySsn() {

		// Invoke a method
		try {
			Customer bankCustomer = this.bank
					.searchCustomerBySsn(ITSOBank381Test.CUSTOMER_SSN);

			// Verify an assertion
			assertEquals(bankCustomer.getSsn(), ITSOBank381Test.CUSTOMER_SSN);
		} catch (InvalidCustomerException e) {
			e.printStackTrace();
		}
	}
}
