package itso.rad7.bank.test.junit;

import static org.junit.Assert.assertEquals;
import itso.rad7.bank.exception.InvalidAccountException;
import itso.rad7.bank.exception.InvalidCustomerException;
import itso.rad7.bank.ifc.Bank;
import itso.rad7.bank.impl.ITSOBank;
import itso.rad7.bank.model.Account;
import itso.rad7.bank.model.Customer;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ITSOBank4Test {

	private Bank bank = null;
	private static final String ACCOUNT_NUMBER = "001-999000777";
	private static final String CUSTOMER_SSN = "111-11-1111";

	@Before
	public void setUp() {

		// Instantiate objects
		this.bank = ITSOBank.getBank();
	}

	@After
	public void tearDown() {}

	@Test
	public final void testSearchAccountByAccountNumber() {

		try {
			// Invoke a method

			Account bankAccount = this.bank
					.searchAccountByAccountNumber(ITSOBank4Test.ACCOUNT_NUMBER);

			// Verify an assertion
			assertEquals(bankAccount.getAccountNumber(),
					ITSOBank4Test.ACCOUNT_NUMBER);
		} catch (InvalidAccountException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testSearchCustomerBySsn() {

		// Invoke a method
		try {
			Customer bankCustomer = this.bank
					.searchCustomerBySsn(ITSOBank4Test.CUSTOMER_SSN);

			// Verify an assertion
			assertEquals(bankCustomer.getSsn(), ITSOBank4Test.CUSTOMER_SSN);
		} catch (InvalidCustomerException e) {
			e.printStackTrace();
		}
	}
}
