def createProvider():

	#if the JDBC Provider exists, then don't do anything
    	prov = AdminControl.completeObjectName("name=" + jdbcProv + ",type=JDBCProvider,Server=" + srvr + ",node=" + nodeName + ",*")
	if len(prov) > 0:
		print "\n***** The JDBC Provider with name: " + jdbcProv + " already exists. So another will not be created"
		return  
	#endif

	provName=['name',jdbcProv]
	impClass=['implementationClassName','org.apache.derby.jdbc.EmbeddedXADataSource']
    	jdbcAttrs=[]
    	jdbcAttrs.append(provName)
    	jdbcAttrs.append(impClass)

	# Create the JDBC Provider using the Derby JDBC Provider (XA) template
    	tmplName = 'Derby JDBC Provider (XA)'
    	templates = AdminConfig.listTemplates("JDBCProvider", tmplName).split(lineSep)
   	tmpl = templates[0]
   	
	serverId = AdminConfig.getid("/Node:" + nodeName + "/Server:" + srvr + "/")

    	AdminConfig.createUsingTemplate("JDBCProvider",serverId,jdbcAttrs,tmpl)
    	AdminConfig.save()
    	print "\n***** STEP 1 completed - The "+jdbcProv + " has been created using the template. Config saved .."
	
#enddef	

def createDS():
	
	#if the DataSource exists, then don't do anything
   	dsId = AdminConfig.getid("/JDBCProvider:" + jdbcProv + "/DataSource:" + dataSourceName + "/")
   	if len(dsId) > 0:
		print "\n***** The DataSource with name: " + dataSourceName + " already exists. So another will not be created"
		return 
	#endif

	dsname=['name',dataSourceName]
	jndiName=['jndiName',jndiDS]
	description=['description','ITSOBank RAD7 Data Source']	
	dsHelperClassname=['datasourceHelperClassname','com.ibm.websphere.rsadapter.DerbyDataStoreHelper']
    	dsAttrs=[]
    	dsAttrs.append(dsname)
    	dsAttrs.append(jndiName)
    	dsAttrs.append(description)
    	dsAttrs.append(dsHelperClassname)
    	
	provId = AdminConfig.getid("/Node:" + nodeName + "/Server:" + srvr + "/JDBCProvider:" + jdbcProv + "/")
    	AdminConfig.create('DataSource',provId,dsAttrs)
	AdminConfig.save()
	print "Done creating the DS. Config saved .."
	
	modifyDS() #modify DS to add the ResourcePropertySet, esp the DatabaseName (location)
	useDSinCMP() # enable the option to use the DS in Container Maanged Persistence (CMP)
	
	print "\n***** STEP 2 completed - Done creating the DS. Config saved .."

#enddef

def modifyDS():
	
	#modify DS to add the ResourcePropertySet, esp the DatabaseName (location)
   	dsId = AdminConfig.getid("/JDBCProvider:" + jdbcProv + "/DataSource:" + dataSourceName + "/")
   	dbnameAttrs = [["name", "databaseName"], ["value", dbasename], ["type", "java.lang.String"], ["description", "This is a required property"]]
   	descrAttrs = [["name", "description"], ["value", ""], ["type", "java.lang.String"]] 
   	passwordAttrs = [["name", "password"], ["value", ""], ["type", "java.lang.String"]]
	loginTimeOutAttrs = [["name", "loginTimeout"], ["value", 0], ["type", "java.lang.Integer"]]
   	propset = []
   	propset.append(dbnameAttrs)
   	propset.append(descrAttrs)
   	propset.append(passwordAttrs)
   	propset.append(loginTimeOutAttrs) 
   	pSet = ["propertySet", [["resourceProperties", propset]]]
   	attrs = [pSet]
   	
   	AdminConfig.modify(dsId, attrs)
	AdminConfig.save()
	print "Done modifying the DS. Config Saved .."
   	
#enddef

def useDSinCMP():
	# This method has steps to enable the option to use the DS in Container Maanged Persistence (CMP)
	dsId = AdminConfig.getid("/JDBCProvider:" + jdbcProv + "/DataSource:" + dataSourceName + "/")
	rra = AdminConfig.getid("/Node:" + nodeName + "/Server:" + srvr + "/J2CResourceAdapter:WebSphere Relational Resource Adapter/")
	    
	nameAttr = ["name", cfname]
	authmechAttr = ["authMechanismPreference", "BASIC_PASSWORD"]
	cmpdsAttr = ["cmpDatasource", dsId]
	attrs = []
	attrs.append(nameAttr)
	attrs.append(authmechAttr)
	attrs.append(cmpdsAttr)
	
	# Create a CMPConnectorFactory, using the DataSource created just now "	
	newcf = AdminConfig.create("CMPConnectorFactory", rra, attrs)
	AdminConfig.save()
	
	# Modify the CMPConnectionFactory to add the Mapping attributes
	mapAuthAttr = ["authDataAlias", ""] 
	mapConfigaliasAttr = ["mappingConfigAlias", ""] 
	mapAttrs = []
	mapAttrs.append(mapAuthAttr)
	mapAttrs.append(mapConfigaliasAttr)
	mappingAttr = ["mapping", mapAttrs]
	attrs2 = []
	attrs2.append(mappingAttr)
	cfId = AdminConfig.getid("/CMPConnectorFactory:"+cfname+"/")
   	AdminConfig.modify(cfId, attrs2)
	AdminConfig.save()

	# Modify the DataSource to add the Mapping attributes
   	AdminConfig.modify(dsId, attrs2)
	AdminConfig.save()
	print "The DS has been modified to use it in CMP. Config saved .."
	
#enddef

def installApp(appEAR, appName):

	# If the Application exists, then update it, otherwise install it	
	try:
		app = AdminApp.view(appName)
	except: 
		print "***** App not found: " + appName + ". Installing it now\n"
		options = "-appname " + appName
		AdminApp.install(appEAR, options)
		AdminConfig.save()
		print "\n***** Done installing App: " + appName + ". Config saved .."
	else:
		if app > 1:
			print "***** The App EXISTS: " + appName + ". Therefore updating it instead\n"
			options = "-operation update -contents " + appEAR
			contentType = 'app'
			AdminApp.update(appName, contentType, options)
			AdminConfig.save()
			print "\n***** Done updating the App: " + appName + ". Config saved .."
		#endif

#enddef

def startApp(appName):

	# If the Application is already started then do not do anything.
	app = AdminControl.completeObjectName("type=Application,name=" + appName + ",*")
	if len(app) > 1:
		print "***** The Application " + appName + " is already STARTED"
		return
	#endif
	
	# If the Application status is not Started, only then do the rest ...
		
	#get the ApplicationManager MBean
	appMgr = AdminControl.queryNames("node=" + nodeName + ",type=ApplicationManager,process=" + srvr + ",*")
	
	#start the Application using the ApplicationManager MBean
	AdminControl.invoke(appMgr,'startApplication',appName)
	print "\n***** The startApplication operation for " + appName + " completed."

#enddef

# *********  MAIN SECTION  *********** #

# Define global variables
lineSep = java.lang.System.getProperty('line.separator')

nodeName = AdminControl.getNode()			# get Node name this script is connected to                   
srvrinfo=AdminConfig.list('Server')   
srvr=AdminConfig.showAttribute(srvrinfo, 'name')	# get server name this script is connected to

jdbcProv       = "ITSO Derby JDBC Provider (XA)"
dataSourceName = "RAD7JythonDS"
cfname         = "RAD7JythonDS_CF"
jndiDS         = "jdbc/itsobankejb"                     # Need to modif to match the applicaiton
dbasename      = "C:/7501code/database/derby/ITSOBANK"  # Need to replace with the location of the Derby database

webappEAR      = "C:/7501code/jython/RAD7EJBWebEAR.ear" # Need to replace with the complete path of the EAR file
ejbappEAR      = "C:/7501code/jython/RAD7EJBEAR.ear"    # Need to replace with the complete path of the EAR file

webappEARName = "RAD7EJBWebEAR"				# display name of the enterprise app
ejbappEARName = "RAD7EJBEAR"				# display name of the enterprise app
   
# Call Methods   
createProvider()   			# Step 1 - create a new JDBC provider 
createDS()         			# Step 2 - create and configure a new DataSource
installApp(webappEAR, webappEARName)	# Step 3 - Install the ITSO Bank Web App 
installApp(ejbappEAR, ejbappEARName)    # Step 4 - Install the ITSO Bank EJB App 
startApp(ejbappEARName)                 # Step 5 - Start the ITSO Bank EJB App
startApp(webappEARName)                 # Step 6 - Start the ITSO Bank EJB App
