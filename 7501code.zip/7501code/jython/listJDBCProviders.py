#
# This script list all defined JDBC providers
#
	
def showJdbcProviders():
	providerEntries = AdminConfig.list("JDBCProvider")
	
	# split long line of entries into individual entries in list
	providerEntryList = providerEntries.split(lf)
	
	# print contents of list
	for provider in providerEntryList:
		print provider	
	
AdminConfig.reset()
cell = AdminControl.getCell()
node = AdminControl.getNode()
lf = java.lang.System.getProperty("line.separator")
slash = java.lang.System.getProperty("file.separator")

print "System information: Cell=" + cell
print "System information: Node=" + node

showJdbcProviders()
	
	