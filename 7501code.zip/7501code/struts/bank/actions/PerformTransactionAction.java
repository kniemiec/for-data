package rad7strutsweb.actions;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import rad7strutsweb.database.DatabaseAccess;
import rad7strutsweb.exceptions.InvalidTransactionException;
import rad7strutsweb.forms.TransactForm;


public class PerformTransactionAction extends Action
{


    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        ActionErrors errors = new ActionErrors();
        ActionForward forward = new ActionForward(); // return value
        
        TransactForm transactForm = (TransactForm) form;
        
       	String ssn = (String)request.getSession().getAttribute("ssn");
    	String accountId = transactForm.getAccountId();
    	BigDecimal balance = transactForm.getBalance();
    	BigDecimal amount = null;
    	
    	try {
    		amount = new BigDecimal(transactForm.getAmount());
    		balance = balance.add(amount);
        	
        	if ( balance.compareTo(new BigDecimal(0)) < 0 ) {
        		throw new InvalidTransactionException(accountId,"DEBIT",amount);
        	}
        } catch ( NumberFormatException e ) {
            errors.add("amount", new ActionError("error.amount"));
        } catch (InvalidTransactionException e ) {
            errors.add("amount", new ActionError("error.amount"));
        }
        
        if (errors.isEmpty()) {
        	try {
        		new DatabaseAccess().updateAccount(ssn, accountId, balance, amount);
            } catch (Exception e) {
            	errors.add("error", new ActionError("errors.systemError"));
            }
        }
    	
        // If a message is required, save the specified key(s)
        // into the request for use by the <struts:errors> tag.

        if (!errors.isEmpty()) {
            saveErrors(request, errors);

            // Forward control to the appropriate 'failure' URI (change name as desired)
            forward = mapping.findForward("failure");
            
            
        } else {

            // Forward control to the appropriate 'success' URI (change name as desired)
            forward = mapping.findForward("success");

        }
        
        // Finish with
        return (forward);

    }

}
