
package rad7strutsweb.beans;

import java.math.BigDecimal;

public class AccountBean {
	
	private String accountId;
	private BigDecimal balance;

	private java.util.List transactions;
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public java.util.List getTransactions() {
		return transactions;
	}
	public void setTransactions(java.util.List transactions) {
		this.transactions = transactions;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
}
