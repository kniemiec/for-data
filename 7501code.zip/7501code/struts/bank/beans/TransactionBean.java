
package rad7strutsweb.beans;

import java.math.BigDecimal;


public class TransactionBean {
	
	private String id;
	private BigDecimal amount;
	private String type;
	private java.util.Date timeStamp;

	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public java.util.Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(java.util.Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
