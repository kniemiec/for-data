
package rad7strutsweb.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DataSourceFactory {
	
	private static DataSource datasource = null;
	
	public static void initialize()
	{
		try {
        	InitialContext initCtxt = new InitialContext();
        	datasource = (DataSource)initCtxt.lookup("jdbc/itsobank");
		} catch (NamingException e){
			e.printStackTrace();
		}
	}
	
	public static DataSource getDataSource()
	{
		if (datasource == null) initialize();
		return datasource;
	}
	
	public static void destroy()
	{
		datasource = null;
	}
}
