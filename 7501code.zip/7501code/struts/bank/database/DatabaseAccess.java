package rad7strutsweb.database;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.sql.DataSource;

import rad7strutsweb.beans.AccountBean;
import rad7strutsweb.beans.CustomerBean;
import rad7strutsweb.beans.TransactionBean;
import rad7strutsweb.exceptions.InvalidCustomerException;

public class DatabaseAccess {
	
	private static final String CUSTOMER_STMT = "select a.title, a.firstname, a.lastname, b.id, b.balance from itso.customer a, itso.account b, itso.accounts_customers c where a.ssn=? and a.ssn=c.customers_ssn and c.accounts_id=b.id";
	private static final String TRANSACTION_STMT = "select a.id, a.transtype, a.transtime, a.amount, b.balance from ITSO.TRANSACTIONS a, ITSO.ACCOUNT b where a.ACCOUNTS_ID=b.id and b.id=?";
	private static final String GET_BALANCE_STMT = "select balance from ITSO.ACCOUNT where id=?";
	private static final String UPDATE_ACCOUNT_STMT = "update ITSO.ACCOUNT SET BALANCE=? WHERE ID=?";
	private static final String INSERT_TRANSACTION_STMT = "insert into ITSO.TRANSACTIONS (ID, TRANSTYPE, TRANSTIME, AMOUNT, ACCOUNTS_ID) VALUES (?, ?, ?, ?, ?)";

   	Connection conn = null;
    PreparedStatement stmt = null;
    PreparedStatement stmt2 = null;
    ResultSet rs = null;

	public DatabaseAccess() { }

	public CustomerBean getCustomer(String ssn) 
			throws InvalidCustomerException, Exception {
		
		CustomerBean customerBean = new CustomerBean();
    	customerBean.setSsn(ssn);
    	
    	boolean customerFound = false;
    	
        try {
        	DataSource ds = DataSourceFactory.getDataSource();
        	conn = ds.getConnection();
    	
        	stmt = conn.prepareStatement( CUSTOMER_STMT );
        	stmt.setString(1,ssn);
        	rs = stmt.executeQuery();
    	
        	ArrayList accountList = new ArrayList();

        	// Assumption - Every customer has at least one account to be valid
        	while ( rs.next() ){
        		if ( !customerFound ) {
        			customerFound = true;
        			customerBean.setTitle(rs.getString("title"));
        			customerBean.setFirstName(rs.getString("firstname"));
        			customerBean.setLastName(rs.getString("lastname"));
        		}
    		
        		AccountBean account = new AccountBean();
        		account.setAccountId(rs.getString("id"));
        		account.setBalance( new BigDecimal(rs.getInt("balance")).divide(new BigDecimal(100)));
        		accountList.add(account);
        	}
    	
        	if (!customerFound){
        		throw new InvalidCustomerException(ssn);
        	}
    	
        	customerBean.setAccounts(accountList);
        	
        } catch (Exception e) {
        	if (!customerFound) {
        		throw new InvalidCustomerException(ssn);
        	} else {
        		e.printStackTrace();
        		throw new Exception();
        	}
        } finally {
        	try{if(rs!=null){rs.close();}}catch(SQLException e){e.printStackTrace();}
        	try{if(stmt!=null){stmt.close();}}catch(SQLException e){e.printStackTrace();}
        	try{if(conn!=null){conn.close();}}catch(SQLException e){e.printStackTrace();}
        }
    	
    	return customerBean;
	}
	
	public CustomerBean getAccount(String ssn, String accountId) 
				throws Exception {
		
		CustomerBean customerBean = new CustomerBean();
    	customerBean.setSsn(ssn);

        try {
        	DataSource ds = DataSourceFactory.getDataSource();
        	conn = ds.getConnection();
        	stmt = conn.prepareStatement( TRANSACTION_STMT );
        	stmt.setString(1,accountId);
        	rs = stmt.executeQuery();
        	
    		ArrayList accounts = new ArrayList();
    		AccountBean account = new AccountBean();
    		account.setAccountId(accountId);
    		
        	ArrayList transactions = null;

        	// Assumption - Every customer has at least one account to be valid
        	while ( rs.next() ){
        		if (transactions==null){
        			transactions = new ArrayList();
        			account.setBalance( new BigDecimal(rs.getInt("balance")).divide(new BigDecimal(100)));
        		}
        		TransactionBean transaction = new TransactionBean();
        		transaction.setId(rs.getString("id"));
        		transaction.setType(rs.getString("transtype"));
        		transaction.setAmount( new BigDecimal(rs.getInt("amount")).divide(new BigDecimal(100)));
        		transaction.setTimeStamp(new java.util.Date(rs.getTimestamp("transtime").getTime()));
        		
        		transactions.add(transaction);
        	}
        	if (transactions==null){
        		account.setBalance( getBalance(conn, accountId) );
        	}
        	
        	account.setTransactions(transactions);
        	accounts.add(account);
        	customerBean.setAccounts(accounts);

        } catch (Exception e) {
        	e.printStackTrace();
        	throw new Exception();
        } finally {
        	try{if(rs!=null){rs.close();}}catch(SQLException e){e.printStackTrace();}
        	try{if(stmt!=null){stmt.close();}}catch(SQLException e){e.printStackTrace();}
        	try{if(conn!=null){conn.close();}}catch(SQLException e){e.printStackTrace();}
        }
        
        return customerBean;
	}
	
    private BigDecimal getBalance ( Connection conn, String accountId) 
    			throws Exception {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        BigDecimal balance = null;

        try {
     		stmt = conn.prepareStatement(GET_BALANCE_STMT);
	    	stmt.setString(1,accountId);
        	rs = stmt.executeQuery();
        	if ( rs.next() ){
        		balance = new BigDecimal(rs.getInt("balance")).divide(new BigDecimal(100));
        	}

        } catch (Exception e) {
         	throw new Exception();
        } finally {
        	try{if(rs!=null){rs.close();}}catch(SQLException e){e.printStackTrace();}
        	try{if(stmt!=null){stmt.close();}}catch(SQLException e){e.printStackTrace();}
        }

        return balance;
    }
    
    public void updateAccount(String ssn, String accountId, BigDecimal balance, BigDecimal amount) 
    				throws Exception {
    	
    	boolean error = false;
    	boolean autoCommit = false;
    	boolean rollback = false;
        try {
        	DataSource ds = DataSourceFactory.getDataSource();
        	conn = ds.getConnection();
        	autoCommit = conn.getAutoCommit();
        	conn.setAutoCommit(false);
           	stmt = conn.prepareStatement( UPDATE_ACCOUNT_STMT );
           	stmt.setInt(1, balance.multiply(new BigDecimal(100)).intValue() );
           	stmt.setString(2,accountId);
            	
           	int rowsAffected = stmt.executeUpdate();
           	
        	updateTransactionLog(conn, ssn, accountId, amount);

        } catch (Exception e) {
    	    e.printStackTrace();
    	    rollback = true;
    	    throw new Exception();
        } finally {
            try {
            	if (conn!=null){
    	        	if(rollback){
    	        		try{conn.rollback();}catch(SQLException e){e.printStackTrace();}
    	        	} else {
    	        		try{conn.commit();}catch(SQLException e){e.printStackTrace();}
    	        	}
    	        	conn.setAutoCommit(autoCommit);
            	}
            } catch (Exception e) {
            	e.printStackTrace();
            	throw new Exception();
            }
            try{if(conn!=null){conn.close();}}catch(SQLException e){e.printStackTrace();}
            try{if(stmt!=null){stmt.close();}}catch(SQLException e){e.printStackTrace();}
        }
    }
    
    private void updateTransactionLog(Connection conn, String ssn, String accountId, BigDecimal amount) 
    				throws Exception {
    	
   	String transType = "CREDIT";
        try {
        	stmt2 = conn.prepareStatement( INSERT_TRANSACTION_STMT );
        	if ( amount.compareTo(new BigDecimal(0)) < 0 ) transType = "DEBIT";
        	String transKey = genPKkey(ssn); 
        	stmt2.setString(1,transKey);
        	stmt2.setString(2, transType);
        	stmt2.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
        	stmt2.setInt(4, amount.multiply(new BigDecimal(100)).intValue() );
         	stmt2.setString(5,accountId);
        	
        	int rowsAffected = stmt2.executeUpdate();
        	
        } catch (Throwable e) {
        	throw new Exception();
        } finally {
        	try{if(stmt2!=null){stmt2.close();}}catch(SQLException e){e.printStackTrace();}
        }
    }

    private String genPKkey(String ssn)
    {
    	StringBuffer buffer = new StringBuffer(ssn);
    	buffer.append("-");
    	buffer.append(System.currentTimeMillis());
    	return buffer.toString();
    }
    
}
