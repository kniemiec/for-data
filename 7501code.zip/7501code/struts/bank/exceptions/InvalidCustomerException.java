
package rad7strutsweb.exceptions;


public class InvalidCustomerException extends Exception {
	private String ssn;
	
	public InvalidCustomerException(String ssn){
		this.ssn=ssn;
	}
	
	public String getMessage(){
		return "Invalid Customer. SSN: " + ssn;
	}

}
