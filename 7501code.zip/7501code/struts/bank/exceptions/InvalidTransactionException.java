
package rad7strutsweb.exceptions;

import java.math.BigDecimal;


public class InvalidTransactionException extends Exception{
	private String transactionType;
	private BigDecimal amount;
	private String accountNumber;
	
	public InvalidTransactionException(String accountNumber, String transactionType, BigDecimal amount){
		this.transactionType=transactionType;
		this.amount=amount;
		this.accountNumber=accountNumber;
	}
	
	public String getMessage(){
		return "Transaction. AccountNumber: " 
			+ accountNumber 
			+ " Transaction: " 
			+ transactionType 
			+ " Amount: $"
			+ amount.setScale(2,BigDecimal.ROUND_HALF_EVEN);
	}

}
