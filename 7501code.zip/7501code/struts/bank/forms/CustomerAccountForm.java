package rad7strutsweb.forms;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * Form bean for a Struts application.
 * Users may access 3 fields on this form:
 * <ul>
 * <li>ssn - [your comment here]
 * <li>accountId - [your comment here]
 * </ul>
 * @version 	1.0
 * @author
 */
public class CustomerAccountForm extends ActionForm

{

    private String ssn = null;

    private String accountId = null;

     public String getSsn() {
    	return ssn;
    }
    public void setSsn(String s) {
    	this.ssn = s;
    }
    public String getAccountId() {
    	return accountId;
    }
    public void setAccountId(String a) {
    	this.accountId = a;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request) {

	// Reset values are provided as samples only. Change as appropriate.

	ssn = null;
	accountId = null;
    }

    public ActionErrors validate(ActionMapping mapping,
	    HttpServletRequest request) {

	ActionErrors errors = new ActionErrors();
	// Validate the fields in your form, adding
	// adding each error to this.errors as found, e.g.

	// if ((field == null) || (field.length() == 0)) {
	//   errors.add("field", new org.apache.struts.action.ActionError("error.field.required"));
	// }
	return errors;

    }
}
