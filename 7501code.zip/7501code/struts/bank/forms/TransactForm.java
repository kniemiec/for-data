package rad7strutsweb.forms;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * Form bean for a Struts application.
 * Users may access 3 fields on this form:
 * <ul>
 * <li>acocuntId - [your comment here]
 * <li>amount - [your comment here]
 * <li>balance - [your comment here]
 * </ul>
 * @version 	1.0
 * @author
 */
public class TransactForm extends ActionForm

{

    private String accountId = null;

    private String amount = null;
    
    BigDecimal balance = null;

    public String getAccountId() {
    	return accountId;
    }
    public void setAccountId(String a) {
    	this.accountId = a;
    }
    public String getAmount() {
    	return amount;
    }
    public void setAmount(String a) {
    	this.amount = a;
    }
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
    public void reset(ActionMapping mapping, HttpServletRequest request) {

	// Reset values are provided as samples only. Change as appropriate.

    accountId = null;
	amount = null;
	balance = null;
    }

    public ActionErrors validate(ActionMapping mapping,
	    HttpServletRequest request) {

	ActionErrors errors = new ActionErrors();
	// Validate the fields in your form, adding
	// adding each error to this.errors as found, e.g.

	// if ((field == null) || (field.length() == 0)) {
	//   errors.add("field", new org.apache.struts.action.ActionError("error.field.required"));
	// }
	return errors;

    }

}
