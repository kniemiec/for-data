package itso.rad7.webapps.command;

import java.math.BigDecimal;

import itso.rad7.bank.ifc.Bank;
import itso.rad7.bank.impl.ITSOBank;
import itso.rad7.bank.model.Account;
import itso.rad7.bank.exception.InvalidAmountException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Transfer command. Will perform a transfer of the specified amount
 * from one account to another.
 * 
 * Parameters:
 * <dl>
 * <dt>amount</dt><dd>The amount of cents to transfer</dd>
 * <dt>accountId</dt><dd>The debit account</dd>
 * <dt>targetAccountId</dt><dd>The credit account</dd>
 * </dl>
 */
public class TransferCommand
		implements Command
{
	/**
	 * Do the actual transfer.
	 * 
	 * @see itso.rad7.webapps.command.Command#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void execute(HttpServletRequest req, HttpServletResponse resp)
			throws Exception
	{
		// Parameters
		String debitAccountNumber = req.getParameter("accountId");
		String creditAccountNumber = req.getParameter("targetAccountId");
		String strAmount = req.getParameter("amount");
		BigDecimal amount = null;
		
		try { amount = new BigDecimal(strAmount); }
		catch (NumberFormatException x) {
			throw new InvalidAmountException(strAmount);
		}
		
		// Control logic
		Bank bank = ITSOBank.getBank();
		bank.transfer(debitAccountNumber, creditAccountNumber, amount);
		
		// Response
		Account account = bank.searchAccountByAccountNumber(debitAccountNumber);
		req.setAttribute("account", account);
	}

	/**
	 * @see itso.rad7.webapps.command.Command#getForwardView()
	 */
	public String getForwardView() {
		return "accountDetails.jsp";
	}
}