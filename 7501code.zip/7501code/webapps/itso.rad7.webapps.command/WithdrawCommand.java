package itso.rad7.webapps.command;

import java.math.BigDecimal;

import itso.rad7.bank.exception.InvalidAmountException;
import itso.rad7.bank.ifc.Bank;
import itso.rad7.bank.impl.ITSOBank;
import itso.rad7.bank.model.Account;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Withdrawal command. Will perform a withdrawal of the specified amount
 * from the specified account.
 * 
 * Parameters:
 * <dl>
 * <dt>amount</dt><dd>The amount cents to withdraw</dd>
 * <dt>accountId</dt><dd>The account number to withdraw from</dd>
 * </dl>
 */
public class WithdrawCommand
		implements Command
{

	/**
	 * Do the actual withdrawal.
	 * 
	 * @see itso.rad7.webapps.command.Command#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void execute(HttpServletRequest req, HttpServletResponse resp)
			throws Exception
	{
		// Parameters
		String accountId = req.getParameter("accountId");
		String strAmount = req.getParameter("amount");
		BigDecimal amount = null;
		
		try { amount = new BigDecimal(strAmount); }
		catch (NumberFormatException x) {
			throw new InvalidAmountException(strAmount);
		}
		
		// Control logic
		Bank bank = ITSOBank.getBank();
		bank.withdraw(accountId, amount);
		
		// Response
		Account account = bank.searchAccountByAccountNumber(accountId);
		req.setAttribute("account", account);
	}

	/**
	 * @see itso.rad7.webapps.command.Command#getForwardView()
	 */
	public String getForwardView() {
		return "accountDetails.jsp";
	}
}