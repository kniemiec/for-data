package itso.rad7.webapps.servlet;


import itso.rad7.bank.ifc.Bank;
import itso.rad7.bank.impl.ITSOBank;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet to update the details for the customer currently logged on.
 *
 * Parameters: 
 * <dl>
 * <dt>title</dt>
 * <dd>The new salutary title for the customer.</dd>
 * <dt>firstName</dt>
 * <dd>The new first name for the customer.</dd>
 * <dt>lastName</dt>
 * <dd>The new last (family) name for the customer.</dd>
 * </dl>
 * 
 * Output (request parameters): None
 * 
 * Forwards to:
 * <dl>
 * <dt>ListAccounts (servlet)</dt>
 * <dd>If the customer is updated and no other error occurred.</dd>
 * 
 * <dt>showException.jsp</dt>
 * <dd>If the customer is not found, or some other error has occurred.</dd>
 * </dl>
 * 
 * @see itso.rad7.bank.model.Customer
 */
public class UpdateCustomer
		extends HttpServlet
		implements Servlet
{
	private static final long serialVersionUID = 6859812308406444467L;

	/**
	 * HTTP GET service method. Calls performTask to service requests.
	 * 
	 * @see performTask(HttpServletRequest req, HttpServletResponse resp)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest req,
	 *      HttpServletResponse resp)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		performTask(req, resp);
	}

	/**
	 * HTTP POST service method. Calls performTask to service requests.
	 * 
	 * @see performTask(HttpServletRequest req, HttpServletResponse resp)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest req,
	 *      HttpServletResponse resp)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		performTask(req, resp);
	}

	/**
	 * This method does the actual servlet processing.
	 * 
	 * @see #doGet(HttpServletRequest, HttpServletResponse)
	 * @see #doPost(HttpServletRequest, HttpServletResponse)
	 */
	private void performTask(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException
	{
		try
		{
			// Get input parameters
			String title = req.getParameter("title");
			String firstName = req.getParameter("firstName");
			String lastName = req.getParameter("lastName");
			
			// retrieve the SSN from the session
			HttpSession session = req.getSession();
			String ssn = (String) session.getAttribute("customerNumber");
			
			// Control logic - Create the new banking facade
			Bank bank = ITSOBank.getBank();
			
			// Update customer information
			bank.updateCustomer(ssn, title, firstName, lastName);
						
			// Call the presentation renderer
			ServletContext ctx = getServletContext();
			RequestDispatcher disp = ctx.getRequestDispatcher("ListAccounts");
			disp.forward(req, resp);
		}
		catch (Exception e)
		{
			// set up error information and forward to the error page
			req.setAttribute("message", e.getMessage());
			req.setAttribute("forward", "index.html");
			ServletContext ctx = getServletContext();
			RequestDispatcher disp = ctx.getRequestDispatcher("showException.jsp");
			disp.forward(req, resp);
		}
	}
}
