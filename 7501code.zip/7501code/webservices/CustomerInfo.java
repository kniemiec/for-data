package org.example.bank.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.example.bank.ws.Customer;
import org.example.bank.ws.CustomerIdType;
import org.example.bank.ws.WsFactory;

/**
 * Servlet implementation class for Servlet: CustomerInfo
 *
 */
 public class CustomerInfo extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
 
	 public CustomerInfo() {
		super();
	}   	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		org.example.www.BankWS_PortTypeProxySDO BankProxy = new org.example.www.BankWS_PortTypeProxySDO();
		CustomerIdType customerId = WsFactory.eINSTANCE.createCustomerIdType();
		String idType = request.getParameter("idType");
		if (idType.equals("SSN"))
			customerId.setSsn(request.getParameter("id"));
		else
			customerId.setSin(request.getParameter("id"));
		Customer customer = BankProxy.getCustomer(customerId);

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML><HEAD><TITLE>Customer Information</TITLE></HEAD>");
		out.println("<BODY><H2>ITSO SDO Web Service Result</H2>");
		out.println("Customer's name is " + customer.getTitle() + " "
				+ customer.getFirstName() + " " + customer.getLastName() + ".");

		if (customer.getSin() == null)
			out.println("<BR>Customer's social security number is "
					+ customer.getSsn() + ".");
		else
			out.println("<BR>Customer's social insurance number is "
					+ customer.getSin() + ".");
		out.println("</BODY></HTML>");
	}  	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}   	  	    
}