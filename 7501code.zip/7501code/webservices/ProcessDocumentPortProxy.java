package com.ibm.rad7.mtom;

import java.awt.Image;
import java.net.URL;

import javax.activation.DataHandler;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

public class ProcessDocumentPortProxy{

    protected Descriptor _descriptor;

    public class Descriptor {
        private com.ibm.rad7.mtom.ProcessDocumentService _service = null;
        private com.ibm.rad7.mtom.ProcessDocumentDelegate _proxy = null;
        private Dispatch<Source> _dispatch = null;

        public Descriptor() {
            _service = new com.ibm.rad7.mtom.ProcessDocumentService();
            initCommon();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new com.ibm.rad7.mtom.ProcessDocumentService(wsdlLocation, serviceName);
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getProcessDocumentPort();
        }

        public com.ibm.rad7.mtom.ProcessDocumentDelegate getProxy() {
            return _proxy;
        }

        public Dispatch<Source> getDispatch() {
            if(_dispatch == null ) {
                QName portQName = new QName("http://mtom.rad7.ibm.com/", "ProcessDocumentPort");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if(!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if(_dispatch != null ) {
            bp = (BindingProvider) _dispatch;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }
    }

    public ProcessDocumentPortProxy() {
        _descriptor = new Descriptor();
    }

    public ProcessDocumentPortProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }

    public byte[] sendWordFile(byte[] arg0) {
        SOAPBinding binding = (SOAPBinding)((BindingProvider)_getDescriptor().getProxy()).getBinding();
        binding.setMTOMEnabled(true);
        return _getDescriptor().getProxy().sendWordFile(arg0);
    }

    public Image sendImage(Image arg0) {
        SOAPBinding binding = (SOAPBinding)((BindingProvider)_getDescriptor().getProxy()).getBinding();
        binding.setMTOMEnabled(true);
        return _getDescriptor().getProxy().sendImage(arg0);
    }

    public DataHandler sendPDFFile(DataHandler arg0) {
        SOAPBinding binding = (SOAPBinding)((BindingProvider)_getDescriptor().getProxy()).getBinding();
        binding.setMTOMEnabled(true);
        return _getDescriptor().getProxy().sendPDFFile(arg0);
    }

}