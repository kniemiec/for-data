package com.xml.rad7.itso.sdo;

import java.math.BigDecimal;
import com.xml.rad7.itso.*;
import com.xml.rad7.itso.util.ItsoResourceUtil;

public class AccountsTest {
	private DocumentRoot createDocumentRoot() {
		DocumentRoot documentRoot = ItsoFactory.eINSTANCE.createDocumentRoot();
		return documentRoot;
	}

	private AccountsType createAccountsType() {
		AccountsType accountsType = ItsoFactory.eINSTANCE.createAccountsType();
		return accountsType;
	}

	private Account createAccount(AccountTypeType accountType, String accountId,
			BigDecimal balance, BigDecimal interest, CustomerInfoType customerInfo) {
		Account account = ItsoFactory.eINSTANCE.createAccount();
		account.setAccountType(accountType);
		account.setAccountId(accountId);
		account.setBalance(balance);
		account.setInterest(interest);
		account.setCustomerInfo(customerInfo);
		return account;
	}

	private CustomerInfoType createAccountInfo(String firstName,
			String lastName, String phoneNumber) {
		CustomerInfoType customerInfo = ItsoFactory.eINSTANCE.createCustomerInfoType();
		customerInfo.setFirstName(firstName);
		customerInfo.setLastName(lastName);
		customerInfo.setPhoneNumber(phoneNumber);
		return customerInfo;
	}

	public static void main(String args[]) throws Exception {

		AccountsTest sample = new AccountsTest();
		DocumentRoot documentRoot = sample.createDocumentRoot();

		AccountsType accountsType = sample.createAccountsType();
		CustomerInfoType customerInfo = sample.createAccountInfo("Henry", "Cui", "(123) 456-7890");
		Account account = sample.createAccount(AccountTypeType.SAVINGS_LITERAL,
				"123456", new BigDecimal(20000.00), new BigDecimal(3.5), customerInfo);
		accountsType.getAccount().add(0, account);
		customerInfo = sample.createAccountInfo("Ueli", "Wahli", "(408) 345-6789");
		account = sample.createAccount(AccountTypeType.FIXED_LITERAL, "222222",
				new BigDecimal(50000.00), new BigDecimal(6.0), customerInfo);
		accountsType.getAccount().add(1, account);
		documentRoot.setAccounts(accountsType);
		
		ItsoResourceUtil.getInstance().save(documentRoot, System.out);
		ItsoResourceUtil.getInstance().save(documentRoot, "accounts.xml");
	}
}
