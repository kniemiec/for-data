package com.xml.rad7.itso.sdo;

import java.io.IOException;

import com.xml.rad7.itso.AccountTypeType;
import com.xml.rad7.itso.AccountsType;
import com.xml.rad7.itso.DocumentRoot;
import com.xml.rad7.itso.impl.AccountsTypeImpl;
import com.xml.rad7.itso.util.ItsoResourceUtil;
import commonj.sdo.DataObject;

public class SDOSample {

	public static void main(String[] args) throws IOException {
		// LOAD the SDO
		System.out.println("\n--- Printing an XML document to System.out ---");
		DocumentRoot documentRoot =
					ItsoResourceUtil.getInstance().load("accounts.xml");
		ItsoResourceUtil.getInstance().save(documentRoot, System.out);
		
		// NAVIGATE the SDO
		AccountsType accountsType = documentRoot.getAccounts();
		DataObject accountsTypeImpl = (AccountsTypeImpl) accountsType;
		DataObject account1 = accountsTypeImpl.getDataObject("Account.0");
		System.out.println("\n\nThe first account is: " + account1 + "\n");
		DataObject account2 = accountsTypeImpl.getDataObject("Account[accountId = '222222']");
		System.out.println("The second account is: " + account2 + "\n");
		DataObject account1CustomerInfo = accountsTypeImpl.getDataObject("Account[accountId = '123456']/CustomerInfo");
		System.out.println("The first account customer information: " + account1CustomerInfo + "\n");
		String account1CustomerName = (String)account1.get("CustomerInfo/FirstName");
		System.out.println("The first account's customer's first name is " + account1CustomerName + "\n");
		
		// UPDATE the SDO
		account1.setString("interest", "10");
		
		DataObject account3 = accountsTypeImpl.createDataObject("Account");
		account3.setString("accountId", "333333");
		account3.set("accountType", AccountTypeType.LOAN_LITERAL);
		account3.setString("balance", "999999");
		account3.setString("interest", "2.5");
		DataObject newCustomerInfo = account3.createDataObject("customerInfo");
		newCustomerInfo.setString("firstName", "Mike");
		newCustomerInfo.setString("lastName", "Smith");
		newCustomerInfo.setString("phoneNumber", "(201) 654-8754");
		
		account2.delete();
		
		System.out.println("\n--- Printing the updated XML document ---");
		ItsoResourceUtil.getInstance().save(documentRoot, System.out);
		
		System.out.println("\n\n--- Done ---");
	}

}
